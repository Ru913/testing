# Security Policy

## Reporting a Vulnerability

If you find a vulnerability in the latest version, please [submit a private advisory](https://github.com/henrygd/beszel/security/advisories/new).

If it's low severity (use best judgement) you may open an issue instead of an advisory.
